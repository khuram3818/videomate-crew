# How to Get VMC3.0.apk — GitHub Actions (Free, No Install)

## What you need
- A free GitHub account → https://github.com/signup
- That's it. No WSL, no Linux, no installs.

---

## Steps (takes about 5 minutes to set up, then 25 min to build)

### Step 1 — Create a GitHub account
Go to https://github.com/signup and sign up (free).

---

### Step 2 — Create a new repository
1. Go to https://github.com/new
2. Repository name: `videomate-crew`
3. Set to **Private** (recommended)
4. Click **Create repository**

---

### Step 3 — Upload these files
In your new repo, click **"uploading an existing file"** link, then upload ALL files from this ZIP maintaining folder structure:

```
app/
  main.py
  buildozer.spec
.github/
  workflows/
    build.yml
```

**Important:** You must keep the folder structure exactly as shown.

Easiest way:
1. Extract this ZIP on your PC
2. On GitHub repo page → click **Add file** → **Upload files**
3. Drag the entire extracted folder contents into the upload box
4. Click **Commit changes**

---

### Step 4 — Watch the build
1. Click the **Actions** tab in your GitHub repo
2. You'll see "Build VideoMate Crew 3.0 APK" running
3. Wait ~25 minutes (first run; subsequent runs are faster due to cache)
4. Green checkmark = success ✅

---

### Step 5 — Download your APK
1. Click the completed Action run
2. Scroll down to **Artifacts**
3. Click **VMC3.0** to download
4. Extract the zip → you get **VMC3.0.apk**

---

### Step 6 — Install on your phone
1. Send VMC3.0.apk to your phone (WhatsApp, USB, Google Drive)
2. On phone: Settings → Security → Allow Unknown Sources (or Install Unknown Apps)
3. Open the APK file → Install → Done ✅

---

## If the build fails
- Click the failed run → click the "build" job → read the red error lines
- Most common fix: the cache is corrupted → click **Re-run jobs**

## Want to rebuild later?
Go to Actions tab → click "Build VideoMate Crew 3.0 APK" → click **Run workflow** button
